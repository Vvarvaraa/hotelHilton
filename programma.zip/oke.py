import sqlite3

connection = sqlite3.connect("hotel_Hil.db")
cursor = connection.cursor()


def print_table_data(cursor, table_name):
    cursor.execute(f"SELECT * FROM {table_name}")
    rows = cursor.fetchall()
    print(f"Данные из таблицы {table_name}:")
    for row in rows:
        print(row)


try:
    cursor.execute('''
            CREATE TABLE Guests (
            GuestID INTEGER PRIMARY KEY AUTOINCREMENT, 
            Name TEXT NOT NULL, 
            Phone TEXT NOT NULL, 
            Email TEXT)
    ''')

    Guests = [
        (1, 'Иван Иванов', '+79161234567', 'ivanov@example.com'),
        (2, 'Анна Смирнова', '+79162345678', 'smirnova@example.com'),
        (3, 'Алексей Кузнецов', '+79161234569', 'kuznetsov@example.com'),
        (4, 'Мария Соколова', '+79161234570', 'sokolova@example.com'),
        (5, 'Дмитрий Попов', '+79161234571', 'popov@example.com'),
        (6, 'Елена Крылова', '+79161234572', 'krylova@example.com'),
        (7, 'Сергей Новиков', '+79161234573', 'novikov@example.com'),
        (8, 'Ольга Федорова', '+79161234574', 'fedorova@example.com'),
        (9, 'Виктор Васильев', '+79161234575', 'vasilyev@example.com'),
        (10, 'Татьяна Зайцева', '+79161234576', 'zaytseva@example.com'),
        (11, 'Андрей Павлов', '+79161234577', 'pavlov@example.com'),
        (12, 'Юлия Морозова', '+79161234578', 'morozova@example.com'),
        (13, 'Владимир Орлов', '+79161234579', 'orlov@example.com'),
        (14, 'Наталья Белова', '+79161234580', 'belova@example.com'),
        (15, 'Константин Громов', '+79161234581', 'gromov@example.com')
    ]

    cursor.executemany(
        "INSERT INTO Guests (GuestID, Name, Phone, Email) VALUES (?, ?, ?, ?)", Guests)


    cursor.execute('''
        CREATE TABLE Rooms (
        RoomID INTEGER PRIMARY KEY AUTOINCREMENT, 
        RoomType TEXT NOT NULL, 
        Status TEXT NOT NULL DEFAULT 'Свободно')
    ''')

    Rooms = [
        (1, 'Одиночный', 'Свободно'),
        (2, 'Двухместный', 'Занято'),
        (3, 'Люкс', 'Свободно'),
        (4, 'Одиночный', 'Занято'),
        (5, 'Двухместный', 'Свободно'),
        (6, 'Люкс', 'Занято'),
        (7, 'Одиночный', 'Свободно'),
        (8, 'Двухместный', 'Свободно'),
        (9, 'Люкс', 'Свободно'),
        (10, 'Одиночный', 'Занято'),
        (11, 'Двухместный', 'Занято')
    ]

    cursor.executemany(
        "INSERT INTO Rooms (RoomID, RoomType, Status) VALUES (?, ?, ?)",
        Rooms)

    cursor.execute('''
        CREATE TABLE Bookings (
        BookingID INTEGER PRIMARY KEY AUTOINCREMENT, 
        GuestID INTEGER NOT NULL, 
        RoomID INTEGER NOT NULL, 
        CheckIn DATE NOT NULL, 
        CheckOut DATE NOT NULL, 
        FOREIGN KEY (GuestID) REFERENCES Guests(GuestID), 
        FOREIGN KEY (RoomID) REFERENCES Rooms(RoomID) )
    ''')

    Bookings = [
        (1, 1, 2, '2024-11-25', '2024-11-30'),
        (2, 2, 3, '2024-12-01', '2024-12-05'),
        (3, 3, 4, '2024-12-10', '2024-12-15'),
        (4, 4, 5, '2024-12-20', '2024-12-25'),
        (5, 5, 6, '2024-12-26', '2025-01-01'),
        (6, 6, 7, '2025-01-02', '2025-01-06'),
        (7, 7, 8, '2025-01-07', '2025-01-12'),
        (8, 8, 9, '2025-01-13', '2025-01-18'),
        (9, 9, 10, '2025-01-19', '2025-01-24'),
        (10, 10, 11, '2025-02-19', '2025-02-23'),
        (11, 11, 2, '2025-01-21', '2025-01-24'),
        (12, 12, 3, '2025-02-25', '2025-02-30'),
        (13, 13, 4, '2025-01-19', '2025-01-24'),
        (15, 15, 6, '2025-01-19', '2025-01-24')
    ]

    cursor.executemany(
        "INSERT INTO Bookings (BookingID, GuestID, RoomID, CheckIn, CheckOut) VALUES (?, ?, ?, ?, ?)",
        Bookings)


    # commit the changes
    connection.commit()

    print_table_data(cursor, 'Guests')
    print_table_data(cursor, 'Rooms')
    print_table_data(cursor, 'Bookings')


except sqlite3.Error as e:
    print(f"Ошибка при работе с SQLite: {e}")

finally:
    connection.close()
