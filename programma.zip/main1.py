import sys
from PyQt6 import QtWidgets, QtSql
from PyQt6.QtWidgets import QMainWindow, QMessageBox
from PyQt6.QtCore import QTime,QTimer, QDate
from PyQt6.QtGui import QPixmap
from hotel_vhod_ui import Ui_Vhod # Импорт интерфейса
from hotel_management_ui3 import Ui_MainWindow  # Импорт интерфейса
from matplotlib import pyplot as plt
from matplotlib.ticker import MaxNLocator

class Vishes(QMainWindow):
    def __init__(self):
        super(Vishes, self).__init__()
        self.ui = Ui_Vhod()
        self.ui.setupUi(self)
        self.ui.lineEdit_2.setEchoMode(QtWidgets.QLineEdit.EchoMode.Password)
        self.ui.pushButton.clicked.connect(self.login)

        self.users = {
        "Anton": "2012",
        "Maria": "2101"

        }

    def login(self):
        login_s = self.ui.lineEdit.text()
        password = self.ui.lineEdit_2.text()
        if login_s in self.users and self.users[login_s] == password:
            QMessageBox.information(self, 'Успешный вход!', "Добро пожаловать!")
            self.main_window = HotelManagementApp()
            self.main_window.show()
            self.close()
        else:
            QMessageBox.warning(self, "Ошибка!", "Неправильный логин или пароль!")

class HotelManagementApp(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        # Грузим лого для фона
        pixmap = QPixmap("Hilton.png")
        self.ui.imageLabel.setPixmap(pixmap)
        self.ui.imageLabel.setScaledContents(True)

        # Текущее время в QTimeEdit
        current_time = QTime.currentTime()
        self.ui.timeEdit.setTime(current_time)

        # Текущая дата в QDateEdit
        current_date = QDate.currentDate()
        self.ui.dateEdit.setDate(current_date)

        # Подключение БД
        self.db = QtSql.QSqlDatabase.addDatabase("QSQLITE")
        self.db.setDatabaseName("hotel_Hil.db")

        if not self.db.open():
            QtWidgets.QMessageBox.critical(
                None, "Database Error", self.db.lastError().text()
            )
            sys.exit(1)

        self.setup_tables()

        # Подключение кнопок
        self.ui.addGuestButton.clicked.connect(self.add_guest)
        self.ui.deleteGuestButton.clicked.connect(self.delete_guest)
        self.ui.updateGuestButton.clicked.connect(self.update_guest)
        self.ui.analyzeButton.clicked.connect(self.analyze_data)
        self.ui.plotButton.clicked.connect(self.plot_graph)

    def setup_tables(self):
        # Настройка таблицы Guests
        self.guest_model = QtSql.QSqlTableModel(self)
        self.guest_model.setTable("Guests")
        self.guest_model.select()
        self.ui.guestTable.setModel(self.guest_model)

        # Настройка таблицы Rooms
        self.room_model = QtSql.QSqlTableModel(self)
        self.room_model.setTable("Rooms")
        self.room_model.select()
        self.ui.roomTable.setModel(self.room_model)

        # Настройка таблицы Bookings
        self.booking_model = QtSql.QSqlTableModel(self)
        self.booking_model.setTable("Bookings")
        self.booking_model.select()
        self.ui.bookingTable.setModel(self.booking_model)

    def add_guest(self):
        """Функция осуществляет добавление нового гостя"""
        name = self.ui.nameInput.text()
        phone = self.ui.phoneInput.text()
        email = self.ui.emailInput.text()

        if not name or not phone:
            QtWidgets.QMessageBox.warning(self, "Input Error", "Name and Phone are required!")
            return

        query = QtSql.QSqlQuery()
        query.prepare("INSERT INTO Guests (Name, Phone, Email) VALUES (?, ?, ?)")
        query.addBindValue(name)
        query.addBindValue(phone)
        query.addBindValue(email)

        if not query.exec():
            QtWidgets.QMessageBox.critical(self, "Database Error", query.lastError().text())
        else:
            self.guest_model.select()
            self.ui.nameInput.clear()
            self.ui.phoneInput.clear()
            self.ui.emailInput.clear()

    def delete_guest(self):
        """Функция осуществляет удаление выбранного гостя"""

        selected = self.ui.guestTable.selectionModel().currentIndex()
        if not selected.isValid():
            QtWidgets.QMessageBox.warning(self, "Selection Error", "No guest selected!")
            return

        guest_id = self.guest_model.record(selected.row()).value("GuestID")
        query = QtSql.QSqlQuery()
        query.prepare("DELETE FROM Guests WHERE GuestID = ?")
        query.addBindValue(guest_id)

        if not query.exec():
            QtWidgets.QMessageBox.critical(self, "Database Error", query.lastError().text())
        else:
            self.guest_model.select()

    def update_guest(self):
        """Функция обновления информации"""
        selected = self.ui.guestTable.selectionModel().currentIndex()
        if not selected.isValid():
            QtWidgets.QMessageBox.warning(self, "Selection Error", "No guest selected!")
            return

        guest_id = self.guest_model.record(selected.row()).value("GuestID")
        current_name = self.guest_model.record(selected.row()).value("Name")
        current_phone = self.guest_model.record(selected.row()).value("Phone")
        current_email = self.guest_model.record(selected.row()).value("Email")

        name = self.ui.nameInput.text() or current_name
        phone = self.ui.phoneInput.text() or current_phone
        email = self.ui.emailInput.text() or current_email

        if not name or not phone:
            QtWidgets.QMessageBox.warning(self, "Input Error", "Name and Phone are required!")
            return

        query = QtSql.QSqlQuery()
        query.prepare("UPDATE Guests SET Name = ?, Phone = ?, Email = ? WHERE GuestID = ?")
        query.addBindValue(name)
        query.addBindValue(phone)
        query.addBindValue(email)
        query.addBindValue(guest_id)

        if not query.exec():
            QtWidgets.QMessageBox.critical(self, "Database Error", query.lastError().text())
        else:
            self.guest_model.select()
            self.ui.nameInput.clear()
            self.ui.phoneInput.clear()
            self.ui.emailInput.clear()

    def analyze_data(self):
        try:
            # Определение общего числа гостей
            query = QtSql.QSqlQuery("SELECT COUNT(*) FROM Guests")
            if query.next():
                total_guests = query.value(0)
                self.ui.totalGuestsLabel.setText(f"Общее количество гостей: {total_guests}")
            else:
                self.ui.totalGuestsLabel.setText("Общее количество гостей: -")

            # Анализ активных бронирований
            query = QtSql.QSqlQuery("SELECT COUNT(*) FROM Bookings WHERE CheckOut > DATE('now')")
            if query.next():
                active_bookings = query.value(0)
                self.ui.activeBookingsLabel.setText(f"Активные бронирования: {active_bookings}")
            else:
                self.ui.activeBookingsLabel.setText("Активные бронирования: -")

            # Анализ по типу номера
            query = QtSql.QSqlQuery("SELECT RoomType, COUNT(*) AS count FROM Rooms GROUP BY RoomType")
            room_type_data = []
            while query.next():
                room_type = query.value(0)
                count = query.value(1)
                room_type_data.append(f"{room_type}: {count}")

            room_type_text = ", ".join(room_type_data) if room_type_data else "-"
            self.ui.roomTypeLabel.setText(f"Типы номеров: {room_type_text}")
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Ошибка анализа", str(e))

    def plot_graph(self):
        try:
            # Запрос данных для графика (количество номеров по типам)
            query = QtSql.QSqlQuery("SELECT RoomType, COUNT(*) FROM Rooms GROUP BY RoomType")
            room_types = []
            counts = []

            while query.next():
                room_types.append(query.value(0))  # Название типа номера
                counts.append(query.value(1))  # Количество

            # Строим графика
            plt.figure(figsize=(8, 6))
            plt.bar(room_types, counts, color='skyblue', edgecolor='black')
            plt.title('Количество номеров по типам', fontsize=16)
            plt.xlabel('Тип номера', fontsize=14)
            plt.ylabel('Количество', fontsize=14)
            plt.gca().yaxis.set_major_locator(MaxNLocator(integer=True))  # Целочисленные деления
            plt.grid(axis='y', linestyle='--', alpha=0.7)
            plt.tight_layout()

            # Смотрим график
            plt.show()
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Ошибка построения графика", str(e))


# запуск
if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window = Vishes()
    window.show()
    sys.exit(app.exec())
